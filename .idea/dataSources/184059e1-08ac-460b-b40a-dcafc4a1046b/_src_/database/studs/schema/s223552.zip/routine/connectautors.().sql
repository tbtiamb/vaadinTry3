create function connectautors() returns integer
LANGUAGE plpgsql
AS $$
DECLARE
names text[] := '{ 
Андерс,
Бертран,
Брендан,
Бьёрн,
Валдемар,
Валентин,
Вильям,
Гай,
Гвидо,
Гертруда,
Говард,
Грейс,
Денис,
Джеймс,
Джеймс,
Джеральд,
Джон,
Джон,
Джон,
Джон,
Камиль,
Кен,
Кеннет,
Луиш Энрике,
Маркус,
Михал,
Павел,
Роб,
Роберту,
Роджер,
Саймон,
Стив,
Томас,
Уолтер,
Фил,
Филип,
Шон,
Юкихиро,
Андерс,
Кеннет,
Paul,
Bertrand,
Lennart,
Zoltán
}'; 

surnames text[] := '{ 
Хейлсберг,
Мейер,
Эйх,
Страуструп,
Селиш,
Турчин,
Селден,
Стил,
ван Россум,
Тирни,
Бромберг,
Хоппер,
Ритчи,
Гослин,
Стрэчен,
Сассмен,
Бэкус,
Кемени,
Маккарти,
Хьюз,
Скальски,
Томпсон,
Айверсон,
ди Фигейреду,
Овермарс,
Москаль,
Ольшта,
Пайк,
Иерузалимски,
Хуэй,
Пейтон,
Декорте,
Курц,
Брайт,
Винтерботтом,
Вадлер,
Дорвард,
Мацумото,
Хейлсберг,
Айверсон,
Hudak,
Meyer,
Augustsson,
Somogyi
}'; 

langs text[] := '{
C#,
Активный Оберон,
JavaScript,
C++,
Lua,
РЕФАЛ,
КОБОЛ,
Scheme,
Python,
КОБОЛ,
КОБОЛ,
КОБОЛ,
Би,
Java,
Groovy,
Scheme,
Фортран,
Basic,
Лисп,
Haskell,
Nemerle,
Би,
J,
Lua,
Game Maker Language(GML),
Nemerle,
Nemerle,
Limbo,
Lua,
J,
Haskell,
Io,
Basic,
D,
Limbo,
Haskell,
Limbo,
Ruby,
Delphi,
АПЛ,
Haskell,
Eiffel,
Haskell,
Mercury
}';

i INTEGER;


begin


i := 1; 
while langs[i] is not null loop
INSERT INTO АВТОР_ЯЗЫКА
VALUES((SELECT ИД_ЭЛЕМЕНТА FROM ЭЛЕМЕНТ WHERE НАЗВАНИЕ = langs[i]), (SELECT ИД_АВТОРА FROM АВТОРЫ WHERE ИМЯ = names[i] AND ФАМИЛИЯ = surnames[i]));

i := i+1; 
end loop;
RETURN 1; 
end;
$$;
